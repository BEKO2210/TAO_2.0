"""
ApprovalGate - TAO/Bittensor Multi-Agent System
Handles SAFE/CAUTION/DANGER classification for all actions.
"""


class ApprovalGate:
    """Approval gate that classifies actions into SAFE, CAUTION, or DANGER."""

    # Classification levels
    SAFE = "SAFE"
    CAUTION = "CAUTION"
    DANGER = "DANGER"

    # Wallet modes
    MODE_NO_WALLET = "NO_WALLET"
    MODE_WATCH_ONLY = "WATCH_ONLY"
    MODE_MANUAL_SIGNING = "MANUAL_SIGNING"

    # Safe actions: read-only, analysis, watch-only
    SAFE_ACTIONS = {
        "read",
        "analyze",
        "query",
        "fetch",
        "paper_trade",
        "wallet_watch_only",
        "portfolio_summary",
        "balance_query",
        "transaction_history",
        "report",
        "monitor",
        "discover",
        "research",
    }

    # Caution actions: require manual override
    CAUTION_ACTIONS = {
        "install",
        "api_call",
        "testnet_interact",
        "setup",
        "configure",
        "clone_repo",
    }

    # Danger actions: blocked without explicit approval
    DANGER_ACTIONS = {
        "wallet_create",
        "sign_transaction",
        "stake",
        "unstake",
        "trade",
        "mainnet_interact",
        "transfer",
        "delegate",
        "register",
        "burn",
    }

    def __init__(self):
        self._rules = self._build_rules()

    def _build_rules(self):
        """Build the complete list of safety rules."""
        return [
            "1. NEVER request or store seed phrases",
            "2. NEVER request or store private keys",
            "3. NEVER auto-execute trades",
            "4. NEVER auto-stake/unstake",
            "5. NEVER auto-sign transactions",
            "6. DANGER-classified actions output plans/checklists only",
            "7. All modes default to NO_WALLET",
            "8. Public wallet addresses only for WATCH_ONLY mode",
        ]

    @property
    def rules(self):
        """Return the list of safety rules."""
        return self._rules

    def classify_action(self, action_type: str, action_params: dict = None) -> str:
        """Classify an action as SAFE, CAUTION, or DANGER.

        Args:
            action_type: The type of action to classify.
            action_params: Additional parameters for the action.

        Returns:
            'SAFE', 'CAUTION', or 'DANGER'

        Raises:
            ValueError: If action_type is not a string.
        """
        if action_type is None or not isinstance(action_type, str):
            raise ValueError(
                f"action_type must be a non-empty string, got {type(action_type).__name__}"
            )

        action_type = action_type.lower().strip()
        if not action_type:
            raise ValueError("action_type cannot be empty string")

        if action_type in self.SAFE_ACTIONS:
            return self.SAFE
        if action_type in self.CAUTION_ACTIONS:
            return self.CAUTION
        if action_type in self.DANGER_ACTIONS:
            return self.DANGER

        # Unknown actions default to CAUTION
        return self.CAUTION

    def can_execute(self, classification: str, mode: str = "default") -> bool:
        """Check if an action can execute based on classification and mode.

        Args:
            classification: The action classification (SAFE, CAUTION, DANGER).
            mode: The wallet/execution mode.

        Returns:
            True if the action can execute, False otherwise.
        """
        if classification == self.SAFE:
            return True
        # CAUTION and DANGER require manual override
        return False

    def can_execute_with_override(self, classification: str, override: bool = False) -> bool:
        """Check if an action can execute with optional manual override.

        Args:
            classification: The action classification.
            override: Whether manual override is granted.

        Returns:
            True if the action can execute.
        """
        if classification == self.SAFE:
            return True
        if classification == self.CAUTION and override:
            return True
        # DANGER is never allowed even with override
        return False

    def validate_plan(self, plan: dict) -> dict:
        """Validate a plan and return classification details.

        Args:
            plan: A dict with 'steps' list of action dicts.

        Returns:
            dict with valid, classification, reasons, and steps_with_classification.
        """
        if not plan or not isinstance(plan, dict):
            return {
                "valid": False,
                "classification": self.DANGER,
                "reasons": ["Plan must be a non-empty dictionary"],
            }

        steps = plan.get("steps", [])
        if not steps:
            return {
                "valid": False,
                "classification": self.DANGER,
                "reasons": ["Plan has no steps"],
            }

        reasons = []
        worst_classification = self.SAFE
        steps_classified = []

        for step in steps:
            action_type = step.get("action", "unknown")
            classification = self.classify_action(action_type, step)
            steps_classified.append({
                "step": step,
                "classification": classification,
            })

            if classification == self.DANGER:
                worst_classification = self.DANGER
                reasons.append(f"Step '{action_type}' is classified as DANGER")
            elif classification == self.CAUTION and worst_classification == self.SAFE:
                worst_classification = self.CAUTION
                reasons.append(f"Step '{action_type}' is classified as CAUTION")

        is_valid = worst_classification == self.SAFE

        return {
            "valid": is_valid,
            "classification": worst_classification,
            "reasons": reasons if reasons else ["All steps are SAFE"],
            "steps": steps_classified,
        }

    def check_wallet_permission(self, action: str, wallet_mode: str) -> bool:
        """Check if a wallet action is allowed in the given wallet mode.

        Args:
            action: The action to check.
            wallet_mode: The current wallet mode.

        Returns:
            True if the action is allowed.
        """
        wallet_mode = wallet_mode.upper()

        if wallet_mode == self.MODE_NO_WALLET:
            # Only read-only actions allowed
            return action in {
                "read", "analyze", "query", "fetch", "report", "monitor",
                "research", "discover",
            }

        if wallet_mode == self.MODE_WATCH_ONLY:
            # Read-only and watch-only actions allowed
            classification = self.classify_action(action)
            return classification == self.SAFE

        if wallet_mode == self.MODE_MANUAL_SIGNING:
            # All SAFE and CAUTION allowed; DANGER still needs explicit approval
            classification = self.classify_action(action)
            return classification in (self.SAFE, self.CAUTION)

        # Unknown mode: only SAFE actions
        classification = self.classify_action(action)
        return classification == self.SAFE
