"""
WalletWatchAgent - TAO/Bittensor Multi-Agent System
Watch-only wallet monitoring agent with strict safety rules.
"""

import re


AGENT_NAME = "wallet_watch"
AGENT_VERSION = "1.0.0"


class WalletWatchAgent:
    """Wallet watch-only agent for monitoring wallet balances and transactions.

    Safety rules (non-negotiable):
    1. NEVER request or store seed phrases
    2. NEVER request or store private keys
    3. NEVER auto-execute trades
    4. NEVER auto-stake/unstake
    5. NEVER auto-sign transactions
    6. All modes default to NO_WALLET
    7. Public wallet addresses only for WATCH_ONLY mode
    """

    MODE_NO_WALLET = "NO_WALLET"
    MODE_WATCH_ONLY = "WATCH_ONLY"
    MODE_MANUAL_SIGNING = "MANUAL_SIGNING"

    def __init__(self, config: dict = None):
        self.config = config or {}
        self._mode = self.config.get("wallet_mode", self.MODE_NO_WALLET)
        self._watch_addresses = []
        self._balance_data = {}
        self._transaction_history = []
        self._seed_phrase_requested = False
        self._private_key_requested = False

    @property
    def mode(self) -> str:
        """Current wallet mode."""
        return self._mode

    @property
    def watch_addresses(self) -> list:
        """List of watched addresses."""
        return self._watch_addresses.copy()

    def validate_input(self, task: dict) -> tuple:
        """Validate task input.

        Returns:
            (bool, str) tuple of (is_valid, message).
        """
        if not task or not isinstance(task, dict):
            return False, "Task must be a non-empty dictionary"
        if "action" not in task:
            return False, "Task must have an 'action' key"
        return True, ""

    def run(self, task: dict) -> dict:
        """Execute a wallet watch task.

        Args:
            task: Dict with 'action' and parameters.

        Returns:
            Result dictionary.
        """
        valid, msg = self.validate_input(task)
        if not valid:
            return {"success": False, "error": msg}

        action = task.get("action", "")

        if action == "add_watch_address":
            return self.add_watch_address(task.get("address", ""))
        elif action == "remove_watch_address":
            return self.remove_watch_address(task.get("address", ""))
        elif action == "portfolio_summary":
            return self.get_portfolio_summary()
        elif action == "balance_query":
            return self.get_balance(task.get("address", ""))
        elif action == "transaction_history":
            return self.get_transaction_history(task.get("address", ""))
        elif action == "set_mode":
            return self.set_mode(task.get("mode", self.MODE_NO_WALLET))
        elif action == "prepare_signing_checklist":
            return self.prepare_signing_checklist(task)
        else:
            return {"success": False, "error": f"Unknown action: {action}"}

    def get_status(self) -> dict:
        """Return agent status."""
        return {
            "agent": AGENT_NAME,
            "version": AGENT_VERSION,
            "mode": self._mode,
            "watch_count": len(self._watch_addresses),
            "addresses": self._watch_addresses.copy(),
        }

    def set_mode(self, mode: str) -> dict:
        """Set wallet mode.

        Args:
            mode: One of NO_WALLET, WATCH_ONLY, MANUAL_SIGNING.

        Returns:
            Result dict.
        """
        valid_modes = {self.MODE_NO_WALLET, self.MODE_WATCH_ONLY, self.MODE_MANUAL_SIGNING}
        if mode not in valid_modes:
            return {"success": False, "error": f"Invalid mode: {mode}"}
        self._mode = mode
        return {"success": True, "mode": mode}

    def add_watch_address(self, address: str) -> dict:
        """Add a watch address.

        Args:
            address: SS58 formatted public address.

        Returns:
            Result dict.
        """
        if self._mode == self.MODE_NO_WALLET:
            return {
                "success": False,
                "error": "Cannot add watch address in NO_WALLET mode",
            }

        if not self._is_valid_ss58(address):
            return {"success": False, "error": f"Invalid SS58 address: {address}"}

        if address not in self._watch_addresses:
            self._watch_addresses.append(address)

        return {"success": True, "address": address, "watch_count": len(self._watch_addresses)}

    def remove_watch_address(self, address: str) -> dict:
        """Remove a watch address.

        Args:
            address: Address to remove.

        Returns:
            Result dict.
        """
        if address in self._watch_addresses:
            self._watch_addresses.remove(address)
            return {"success": True, "removed": address}
        return {"success": False, "error": f"Address not found: {address}"}

    def get_portfolio_summary(self) -> dict:
        """Get portfolio summary (read-only).

        Returns:
            Portfolio summary dict.
        """
        total_balance = sum(self._balance_data.values()) if self._balance_data else 0
        return {
            "success": True,
            "read_only": True,
            "mode": self._mode,
            "total_balance": total_balance,
            "address_count": len(self._watch_addresses),
            "addresses": self._watch_addresses.copy(),
        }

    def get_balance(self, address: str) -> dict:
        """Get balance for an address (read-only).

        Args:
            address: Wallet address.

        Returns:
            Balance info dict.
        """
        balance = self._balance_data.get(address, 0)
        return {
            "success": True,
            "read_only": True,
            "address": address,
            "balance": balance,
        }

    def get_transaction_history(self, address: str) -> dict:
        """Get transaction history (read-only).

        Args:
            address: Wallet address.

        Returns:
            Transaction history dict.
        """
        history = [
            tx for tx in self._transaction_history
            if tx.get("address") == address or not address
        ]
        return {
            "success": True,
            "read_only": True,
            "address": address,
            "transactions": history,
        }

    def prepare_signing_checklist(self, task: dict) -> dict:
        """Prepare a manual signing checklist.

        Returns:
            Checklist dict for manual signing.
        """
        if self._mode != self.MODE_MANUAL_SIGNING:
            return {
                "success": False,
                "error": "Manual signing checklist only available in MANUAL_SIGNING mode",
            }

        return {
            "success": True,
            "checklist": [
                "1. Verify the transaction details on a secure offline device",
                "2. Confirm the recipient address matches your intention",
                "3. Check the amount is correct",
                "4. Review network fees",
                "5. Sign the transaction manually using your hardware wallet",
                "6. Broadcast the signed transaction manually",
                "7. Verify the transaction on-chain after broadcast",
            ],
            "mode": self.MODE_MANUAL_SIGNING,
            "warning": "This agent will NEVER ask for your private key or seed phrase",
        }

    def sign_transaction(self, *args, **kwargs) -> dict:
        """Signing is NEVER allowed - returns error.

        Returns:
            Error dict.
        """
        return {
            "success": False,
            "error": "This agent cannot sign transactions. Use MANUAL_SIGNING mode with a hardware wallet.",
        }

    def stake(self, *args, **kwargs) -> dict:
        """Staking is NEVER allowed automatically.

        Returns:
            Error dict.
        """
        return {
            "success": False,
            "error": "Automatic staking is disabled. Use manual signing.",
        }

    def trade(self, *args, **kwargs) -> dict:
        """Trading is NEVER allowed automatically.

        Returns:
            Error dict.
        """
        return {
            "success": False,
            "error": "Automatic trading is disabled. Use manual signing.",
        }

    @staticmethod
    def _is_valid_ss58(address: str) -> bool:
        """Validate SS58 address format.

        Args:
            address: Address to validate.

        Returns:
            True if valid SS58 format.
        """
        if not address or not isinstance(address, str):
            return False
        # SS58 addresses start with '5' and are 48 characters long
        return bool(re.match(r"^5[A-HJ-NP-Za-km-z1-9]{47}$", address))

    @property
    def requested_seed_phrase(self) -> bool:
        """Whether seed phrase was ever requested (should always be False)."""
        return self._seed_phrase_requested

    @property
    def requested_private_key(self) -> bool:
        """Whether private key was ever requested (should always be False)."""
        return self._private_key_requested

    @property
    def wallet_data_local(self) -> bool:
        """Wallet data is stored locally, not on remote servers."""
        return True
