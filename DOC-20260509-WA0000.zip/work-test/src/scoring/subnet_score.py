"""
SubnetScorer - TAO/Bittensor Multi-Agent System
Scores subnets across multiple dimensions for evaluation.
"""


class SubnetScorer:
    """Scores subnets across multiple weighted dimensions."""

    # Weight configuration for scoring dimensions
    WEIGHTS = {
        "technical_fit": 15,
        "hardware_fit": 15,
        "setup_complexity": 10,
        "doc_quality": 10,
        "competition": 10,
        "reward_realism": 10,
        "maintenance": 10,
        "security_risk": 5,
        "learning_value": 8,
        "long_term": 7,
    }

    def __init__(self):
        self._validate_weights()

    def _validate_weights(self):
        """Validate that weights sum to 100."""
        total = sum(self.WEIGHTS.values())
        if total != 100:
            raise RuntimeError(f"Weights must sum to 100, got {total}")

    def score_subnet(self, subnet_data: dict) -> dict:
        """Calculate overall score for a subnet.

        Args:
            subnet_data: Dictionary with subnet information.

        Returns:
            Dictionary with score, breakdown, and recommendation.
        """
        if not subnet_data or not isinstance(subnet_data, dict):
            return {
                "score": 0,
                "error": "subnet_data must be a non-empty dictionary",
                "breakdown": {},
            }

        breakdown = self._calculate_breakdown(subnet_data)
        total_score = sum(breakdown.values())
        total_score = max(0, min(100, total_score))

        recommendation = self.get_recommendation(total_score)

        return {
            "score": total_score,
            "breakdown": breakdown,
            "recommendation": recommendation,
        }

    def _calculate_breakdown(self, data: dict) -> dict:
        """Calculate score breakdown for each dimension."""
        breakdown = {}
        breakdown["technical_fit"] = self.score_technical_fit(data)
        breakdown["hardware_fit"] = self.score_hardware_fit(data)
        breakdown["setup_complexity"] = self.score_setup_complexity(data)
        breakdown["doc_quality"] = self.score_doc_quality(data)
        breakdown["competition"] = self.score_competition(data)
        breakdown["reward_realism"] = self.score_reward_realism(data)
        breakdown["maintenance"] = self.score_maintenance(data)
        breakdown["security_risk"] = self.score_security_risk(data)
        breakdown["learning_value"] = self.score_learning_value(data)
        breakdown["long_term"] = self.score_long_term(data)
        return breakdown

    def score_technical_fit(self, data: dict) -> float:
        """Score technical fit (0-15 points based on weight)."""
        raw = data.get("technical_fit", 5)
        if raw is None:
            raw = 5
        return (max(0, min(10, raw)) / 10.0) * self.WEIGHTS["technical_fit"]

    def score_hardware_fit(self, data: dict) -> float:
        """Score hardware compatibility (0-15 points)."""
        raw = data.get("hardware_fit", 5)
        if raw is None:
            raw = 5
        return (max(0, min(10, raw)) / 10.0) * self.WEIGHTS["hardware_fit"]

    def score_setup_complexity(self, data: dict) -> float:
        """Score setup complexity - higher complexity = lower score (0-10 points)."""
        raw = data.get("setup_complexity", 5)
        if raw is None:
            raw = 5
        # Invert: low complexity = high score
        inverted = 10 - max(0, min(10, raw))
        return (inverted / 10.0) * self.WEIGHTS["setup_complexity"]

    def score_doc_quality(self, data: dict) -> float:
        """Score documentation quality (0-10 points)."""
        raw = data.get("doc_quality", 5)
        if raw is None:
            raw = 5
        return (max(0, min(10, raw)) / 10.0) * self.WEIGHTS["doc_quality"]

    def score_competition(self, data: dict) -> float:
        """Score competition level - moderate competition = best (0-10 points)."""
        raw = data.get("competition", 5)
        if raw is None:
            raw = 5
        # Optimal at 5 (moderate), penalty at extremes
        distance_from_optimal = abs(max(0, min(10, raw)) - 5)
        score = (10 - distance_from_optimal * 2)
        return (max(0, score) / 10.0) * self.WEIGHTS["competition"]

    def score_reward_realism(self, data: dict) -> float:
        """Score reward realism (0-10 points)."""
        raw = data.get("reward_realism", 5)
        if raw is None:
            raw = 5
        return (max(0, min(10, raw)) / 10.0) * self.WEIGHTS["reward_realism"]

    def score_maintenance(self, data: dict) -> float:
        """Score maintenance burden - low burden = high score (0-10 points)."""
        raw = data.get("maintenance", 5)
        if raw is None:
            raw = 5
        inverted = 10 - max(0, min(10, raw))
        return (inverted / 10.0) * self.WEIGHTS["maintenance"]

    def score_security_risk(self, data: dict) -> float:
        """Score security risk - low risk = high score (0-5 points)."""
        raw = data.get("security_risk", 5)
        if raw is None:
            raw = 5
        # Invert: low risk = high score
        inverted = 10 - max(0, min(10, raw))
        return (inverted / 10.0) * self.WEIGHTS["security_risk"]

    def score_learning_value(self, data: dict) -> float:
        """Score learning value (0-8 points)."""
        raw = data.get("learning_value", 5)
        if raw is None:
            raw = 5
        return (max(0, min(10, raw)) / 10.0) * self.WEIGHTS["learning_value"]

    def score_long_term(self, data: dict) -> float:
        """Score long-term viability (0-7 points)."""
        raw = data.get("long_term", 5)
        if raw is None:
            raw = 5
        return (max(0, min(10, raw)) / 10.0) * self.WEIGHTS["long_term"]

    def get_recommendation(self, score: float) -> str:
        """Get recommendation based on total score.

        Args:
            score: The total score (0-100).

        Returns:
            Recommendation string.
        """
        if score >= 70:
            return "HIGHLY_RECOMMENDED"
        elif score >= 40:
            return "WORTH_CONSIDERING"
        else:
            return "NOT_RECOMMENDED"

    @property
    def weights(self) -> dict:
        """Return the scoring weights."""
        return self.WEIGHTS.copy()

    @property
    def weight_sum(self) -> int:
        """Return the sum of all weights."""
        return sum(self.WEIGHTS.values())
