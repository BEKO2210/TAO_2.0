"""
RiskScorer - TAO/Bittensor Multi-Agent System
Calculates risk scores across multiple categories.
"""


class RiskScorer:
    """Calculates risk scores for subnets, repos, and trades."""

    RISK_LOW = "LOW"
    RISK_MEDIUM = "MEDIUM"
    RISK_HIGH = "HIGH"
    RISK_CRITICAL = "CRITICAL"

    # Risk category thresholds
    THRESHOLDS = {
        RISK_LOW: (0, 25),
        RISK_MEDIUM: (25, 50),
        RISK_HIGH: (50, 75),
        RISK_CRITICAL: (75, 100),
    }

    def __init__(self):
        pass

    def calculate_risk(self, context: dict) -> dict:
        """Calculate overall risk from context.

        Args:
            context: Dictionary with risk context data.

        Returns:
            Dictionary with risk scores and levels.

        Raises:
            ValueError: If context is empty or None.
        """
        if not context:
            raise ValueError("context cannot be empty or None")

        result = {
            "categories": {},
            "overall_score": 0.0,
            "overall_level": self.RISK_LOW,
            "should_veto": False,
        }

        # Calculate subnet risk if present
        if "subnet" in context:
            subnet_risk = self.calculate_subnet_risk(context["subnet"])
            result["categories"]["subnet"] = subnet_risk

        # Calculate repo risk if present
        if "repo" in context:
            repo_risk = self.calculate_repo_risk(context["repo"])
            result["categories"]["repo"] = repo_risk

        # Calculate trade risk if present
        if "trade" in context:
            trade_risk = self.calculate_trade_risk(context["trade"])
            result["categories"]["trade"] = trade_risk

        # Calculate overall score as weighted average
        if result["categories"]:
            scores = [c["score"] for c in result["categories"].values()]
            result["overall_score"] = round(sum(scores) / len(scores), 2)
            result["overall_level"] = self.get_risk_level(result["overall_score"])
            result["should_veto"] = self.should_veto(result["overall_level"])

        return result

    def calculate_subnet_risk(self, subnet_data: dict) -> dict:
        """Calculate risk for a subnet.

        Returns dict with score (0-100) and level.
        """
        age_days = subnet_data.get("age_days", 30)
        validator_count = subnet_data.get("validator_count", 10)
        has_audit = subnet_data.get("has_audit", False)
        anonymous_team = subnet_data.get("anonymous_team", False)
        reward_fluctuation = subnet_data.get("reward_fluctuation", 0.5)

        score = 0.0

        # Newer subnets are riskier
        if age_days < 30:
            score += 25
        elif age_days < 90:
            score += 15
        elif age_days < 180:
            score += 5

        # Fewer validators = riskier
        if validator_count < 5:
            score += 25
        elif validator_count < 15:
            score += 10

        # No audit = riskier
        if not has_audit:
            score += 20

        # Anonymous team = riskier
        if anonymous_team:
            score += 15

        # High reward fluctuation = riskier
        score += min(20, reward_fluctuation * 20)

        score = min(100, score)

        return {
            "score": round(score, 2),
            "level": self.get_risk_level(score),
        }

    def calculate_repo_risk(self, repo_data: dict) -> dict:
        """Calculate risk for a GitHub repository.

        Returns dict with score (0-100) and level.
        """
        stars = repo_data.get("stars", 0)
        last_commit_days = repo_data.get("last_commit_days", 365)
        has_contributors = repo_data.get("has_contributors", False)
        has_license = repo_data.get("has_license", False)
        suspicious_patterns = repo_data.get("suspicious_patterns", [])

        score = 0.0

        # Very few stars = riskier
        if stars < 10:
            score += 30
        elif stars < 50:
            score += 15
        elif stars < 100:
            score += 5

        # Inactive repos are riskier
        if last_commit_days > 180:
            score += 25
        elif last_commit_days > 90:
            score += 10

        # No contributors = riskier
        if not has_contributors:
            score += 15

        # No license = riskier
        if not has_license:
            score += 10

        # Suspicious patterns = much riskier
        score += len(suspicious_patterns) * 10

        score = min(100, score)

        return {
            "score": round(score, 2),
            "level": self.get_risk_level(score),
        }

    def calculate_trade_risk(self, trade_data: dict) -> dict:
        """Calculate risk for a trade.

        Returns dict with score (0-100) and level.
        """
        amount_tao = trade_data.get("amount_tao", 0)
        volatility = trade_data.get("volatility", 0.5)
        liquidity = trade_data.get("liquidity", "medium")
        slippage_tolerance = trade_data.get("slippage_tolerance", 0.02)

        score = 0.0

        # Larger amounts = riskier
        if amount_tao > 100:
            score += 30
        elif amount_tao > 10:
            score += 15
        elif amount_tao > 1:
            score += 5

        # Higher volatility = riskier
        score += min(30, volatility * 30)

        # Low liquidity = riskier
        if liquidity == "low":
            score += 20
        elif liquidity == "medium":
            score += 10

        # High slippage tolerance = riskier
        if slippage_tolerance > 0.05:
            score += 15
        elif slippage_tolerance > 0.02:
            score += 5

        score = min(100, score)

        return {
            "score": round(score, 2),
            "level": self.get_risk_level(score),
        }

    def get_risk_level(self, score: float) -> str:
        """Get risk level from score.

        Args:
            score: Risk score (0-100).

        Returns:
            Risk level string.
        """
        if score >= 75:
            return self.RISK_CRITICAL
        elif score >= 50:
            return self.RISK_HIGH
        elif score >= 25:
            return self.RISK_MEDIUM
        return self.RISK_LOW

    def should_veto(self, risk_level: str) -> bool:
        """Determine if action should be vetoed based on risk level.

        Args:
            risk_level: The risk level string.

        Returns:
            True if the action should be vetoed.
        """
        return risk_level == self.RISK_CRITICAL

    @property
    def risk_categories(self) -> list:
        """Return the list of risk categories."""
        return [self.RISK_LOW, self.RISK_MEDIUM, self.RISK_HIGH, self.RISK_CRITICAL]
