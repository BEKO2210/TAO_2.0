"""
tests/test_risk_score.py
Comprehensive tests for the RiskScorer class.

Tests cover:
- Risk calculation structure and categories
- Individual risk type calculations (subnet, repo, trade)
- Risk level determination
- Veto behavior
- Edge cases and error handling
"""

import pytest

from src.scoring.risk_score import RiskScorer


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def risk_scorer():
    """Provide a fresh RiskScorer instance."""
    return RiskScorer()


@pytest.fixture
def low_risk_subnet():
    """Low-risk subnet data."""
    return {
        "age_days": 365,
        "validator_count": 50,
        "has_audit": True,
        "anonymous_team": False,
        "reward_fluctuation": 0.1,
    }


@pytest.fixture
def high_risk_subnet():
    """High-risk subnet data."""
    return {
        "age_days": 7,
        "validator_count": 2,
        "has_audit": False,
        "anonymous_team": True,
        "reward_fluctuation": 0.9,
    }


@pytest.fixture
def safe_repo():
    """Safe GitHub repository data."""
    return {
        "stars": 500,
        "last_commit_days": 5,
        "has_contributors": True,
        "has_license": True,
        "suspicious_patterns": [],
    }


@pytest.fixture
def suspicious_repo():
    """Suspicious GitHub repository data."""
    return {
        "stars": 2,
        "last_commit_days": 300,
        "has_contributors": False,
        "has_license": False,
        "suspicious_patterns": ["hardcoded_key", "obfuscated_code", "malicious_import"],
    }


@pytest.fixture
def low_risk_trade():
    """Low-risk trade data."""
    return {
        "amount_tao": 0.5,
        "volatility": 0.1,
        "liquidity": "high",
        "slippage_tolerance": 0.01,
    }


@pytest.fixture
def high_risk_trade():
    """High-risk trade data."""
    return {
        "amount_tao": 500,
        "volatility": 0.8,
        "liquidity": "low",
        "slippage_tolerance": 0.1,
    }


# ---------------------------------------------------------------------------
# 1. Basic structure
# ---------------------------------------------------------------------------

def test_calculate_risk_returns_dict(risk_scorer, low_risk_subnet):
    """calculate_risk must return a dictionary with expected keys."""
    result = risk_scorer.calculate_risk({"subnet": low_risk_subnet})
    assert isinstance(result, dict), "Result must be a dictionary"
    assert "categories" in result
    assert "overall_score" in result
    assert "overall_level" in result
    assert "should_veto" in result


# ---------------------------------------------------------------------------
# 2. Subnet risk
# ---------------------------------------------------------------------------

def test_subnet_risk_low(risk_scorer, low_risk_subnet):
    """Low-risk subnet must have LOW risk level."""
    result = risk_scorer.calculate_risk({"subnet": low_risk_subnet})
    subnet_risk = result["categories"]["subnet"]
    assert subnet_risk["level"] == RiskScorer.RISK_LOW, (
        f"Low-risk subnet should be LOW, got {subnet_risk['level']}"
    )
    assert subnet_risk["score"] < 25


def test_subnet_risk_high(risk_scorer, high_risk_subnet):
    """High-risk subnet must have HIGH or CRITICAL risk level."""
    result = risk_scorer.calculate_risk({"subnet": high_risk_subnet})
    subnet_risk = result["categories"]["subnet"]
    assert subnet_risk["level"] in (RiskScorer.RISK_HIGH, RiskScorer.RISK_CRITICAL), (
        f"High-risk subnet should be HIGH/CRITICAL, got {subnet_risk['level']}"
    )
    assert subnet_risk["score"] >= 50


# ---------------------------------------------------------------------------
# 3. Repo risk
# ---------------------------------------------------------------------------

def test_repo_risk_safe_repo(risk_scorer, safe_repo):
    """Safe repo must have LOW risk level."""
    result = risk_scorer.calculate_risk({"repo": safe_repo})
    repo_risk = result["categories"]["repo"]
    assert repo_risk["level"] == RiskScorer.RISK_LOW, (
        f"Safe repo should be LOW, got {repo_risk['level']}"
    )


def test_repo_risk_suspicious_repo(risk_scorer, suspicious_repo):
    """Suspicious repo must have HIGH or CRITICAL risk level."""
    result = risk_scorer.calculate_risk({"repo": suspicious_repo})
    repo_risk = result["categories"]["repo"]
    assert repo_risk["level"] in (RiskScorer.RISK_HIGH, RiskScorer.RISK_CRITICAL), (
        f"Suspicious repo should be HIGH/CRITICAL, got {repo_risk['level']}"
    )


# ---------------------------------------------------------------------------
# 4. Trade risk
# ---------------------------------------------------------------------------

def test_trade_risk_low(risk_scorer, low_risk_trade):
    """Low-risk trade must have LOW risk level."""
    result = risk_scorer.calculate_risk({"trade": low_risk_trade})
    trade_risk = result["categories"]["trade"]
    assert trade_risk["level"] == RiskScorer.RISK_LOW, (
        f"Low-risk trade should be LOW, got {trade_risk['level']}"
    )


def test_trade_risk_high(risk_scorer, high_risk_trade):
    """High-risk trade must have HIGH or CRITICAL risk level."""
    result = risk_scorer.calculate_risk({"trade": high_risk_trade})
    trade_risk = result["categories"]["trade"]
    assert trade_risk["level"] in (RiskScorer.RISK_HIGH, RiskScorer.RISK_CRITICAL), (
        f"High-risk trade should be HIGH/CRITICAL, got {trade_risk['level']}"
    )


# ---------------------------------------------------------------------------
# 5. Risk level determination
# ---------------------------------------------------------------------------

def test_get_risk_level_low(risk_scorer):
    """Score 0-24 must return LOW."""
    assert risk_scorer.get_risk_level(0) == RiskScorer.RISK_LOW
    assert risk_scorer.get_risk_level(10) == RiskScorer.RISK_LOW
    assert risk_scorer.get_risk_level(24.9) == RiskScorer.RISK_LOW


def test_get_risk_level_medium(risk_scorer):
    """Score 25-49 must return MEDIUM."""
    assert risk_scorer.get_risk_level(25) == RiskScorer.RISK_MEDIUM
    assert risk_scorer.get_risk_level(35) == RiskScorer.RISK_MEDIUM
    assert risk_scorer.get_risk_level(49.9) == RiskScorer.RISK_MEDIUM


def test_get_risk_level_high(risk_scorer):
    """Score 50-74 must return HIGH."""
    assert risk_scorer.get_risk_level(50) == RiskScorer.RISK_HIGH
    assert risk_scorer.get_risk_level(65) == RiskScorer.RISK_HIGH
    assert risk_scorer.get_risk_level(74.9) == RiskScorer.RISK_HIGH


def test_get_risk_level_critical(risk_scorer):
    """Score 75-100 must return CRITICAL."""
    assert risk_scorer.get_risk_level(75) == RiskScorer.RISK_CRITICAL
    assert risk_scorer.get_risk_level(90) == RiskScorer.RISK_CRITICAL
    assert risk_scorer.get_risk_level(100) == RiskScorer.RISK_CRITICAL


# ---------------------------------------------------------------------------
# 6. Veto behavior
# ---------------------------------------------------------------------------

def test_should_veto_critical_returns_true(risk_scorer):
    """CRITICAL risk level must trigger veto."""
    assert risk_scorer.should_veto(RiskScorer.RISK_CRITICAL) is True


def test_should_veto_low_returns_false(risk_scorer):
    """LOW risk level must NOT trigger veto."""
    assert risk_scorer.should_veto(RiskScorer.RISK_LOW) is False


def test_should_veto_medium_returns_false(risk_scorer):
    """MEDIUM risk level must NOT trigger veto."""
    assert risk_scorer.should_veto(RiskScorer.RISK_MEDIUM) is False


# ---------------------------------------------------------------------------
# 7. Error handling
# ---------------------------------------------------------------------------

def test_empty_context_raises_error(risk_scorer):
    """Empty or None context must raise ValueError."""
    with pytest.raises(ValueError):
        risk_scorer.calculate_risk(None)
    with pytest.raises(ValueError):
        risk_scorer.calculate_risk({})


# ---------------------------------------------------------------------------
# 8. Risk categories
# ---------------------------------------------------------------------------

def test_risk_categories_present(risk_scorer):
    """All four risk levels must be defined."""
    categories = risk_scorer.risk_categories
    assert RiskScorer.RISK_LOW in categories
    assert RiskScorer.RISK_MEDIUM in categories
    assert RiskScorer.RISK_HIGH in categories
    assert RiskScorer.RISK_CRITICAL in categories
    assert len(categories) == 4


# ---------------------------------------------------------------------------
# 9. Overall score calculation
# ---------------------------------------------------------------------------

def test_overall_score_is_average_of_categories(risk_scorer, low_risk_subnet, safe_repo):
    """Overall score must be the average of individual category scores."""
    result = risk_scorer.calculate_risk({
        "subnet": low_risk_subnet,
        "repo": safe_repo,
    })
    subnet_score = result["categories"]["subnet"]["score"]
    repo_score = result["categories"]["repo"]["score"]
    expected_average = round((subnet_score + repo_score) / 2, 2)
    assert result["overall_score"] == expected_average, (
        f"Overall score {result['overall_score']} != average {expected_average}"
    )


def test_should_veto_from_context(risk_scorer, high_risk_subnet, suspicious_repo):
    """Context with critical risk must set should_veto=True."""
    result = risk_scorer.calculate_risk({
        "subnet": high_risk_subnet,
        "repo": suspicious_repo,
    })
    # If overall level is CRITICAL, should_veto must be True
    if result["overall_level"] == RiskScorer.RISK_CRITICAL:
        assert result["should_veto"] is True
    # Otherwise should_veto must be False
    else:
        assert result["should_veto"] is False
