"""
tests/test_subnet_score.py
Comprehensive tests for the SubnetScorer class.

Tests cover:
- Score structure and range validation
- Individual dimension scoring
- Recommendation logic
- Missing data handling
- Weight validation
"""

import pytest

from src.scoring.subnet_score import SubnetScorer


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def scorer():
    """Provide a fresh SubnetScorer instance."""
    return SubnetScorer()


@pytest.fixture
def perfect_subnet():
    """Subnet data with perfect scores across all dimensions."""
    return {
        "technical_fit": 10,
        "hardware_fit": 10,
        "setup_complexity": 0,  # low complexity = high score
        "doc_quality": 10,
        "competition": 5,  # optimal
        "reward_realism": 10,
        "maintenance": 0,  # low burden = high score
        "security_risk": 0,  # low risk = high score
        "learning_value": 10,
        "long_term": 10,
    }


@pytest.fixture
def mediocre_subnet():
    """Subnet data with average scores."""
    return {
        "technical_fit": 5,
        "hardware_fit": 5,
        "setup_complexity": 5,
        "doc_quality": 5,
        "competition": 5,
        "reward_realism": 5,
        "maintenance": 5,
        "security_risk": 5,
        "learning_value": 5,
        "long_term": 5,
    }


@pytest.fixture
def poor_subnet():
    """Subnet data with poor scores across all dimensions."""
    return {
        "technical_fit": 0,
        "hardware_fit": 0,
        "setup_complexity": 10,  # high complexity = low score
        "doc_quality": 0,
        "competition": 0,  # no competition = bad
        "reward_realism": 0,
        "maintenance": 10,  # high burden = low score
        "security_risk": 10,  # high risk = low score
        "learning_value": 0,
        "long_term": 0,
    }


# ---------------------------------------------------------------------------
# 1. Basic structure
# ---------------------------------------------------------------------------

def test_score_subnet_returns_dict_with_score(scorer, perfect_subnet):
    """score_subnet must return a dict with 'score' key."""
    result = scorer.score_subnet(perfect_subnet)
    assert isinstance(result, dict), "Result must be a dictionary"
    assert "score" in result, "Result must contain 'score' key"
    assert isinstance(result["score"], (int, float)), "Score must be numeric"


def test_score_in_valid_range_0_to_100(scorer, perfect_subnet, poor_subnet, mediocre_subnet):
    """Score must always be in range [0, 100]."""
    for data, label in [(perfect_subnet, "perfect"), (poor_subnet, "poor"), (mediocre_subnet, "mediocre")]:
        result = scorer.score_subnet(data)
        assert 0 <= result["score"] <= 100, (
            f"Score for {label} subnet out of range: {result['score']}"
        )


# ---------------------------------------------------------------------------
# 2. Individual dimension scoring
# ---------------------------------------------------------------------------

def test_technical_fit_scoring(scorer):
    """Technical fit scoring must map 0-10 to 0-15 points."""
    assert scorer.score_technical_fit({"technical_fit": 0}) == 0
    assert scorer.score_technical_fit({"technical_fit": 10}) == 15
    assert scorer.score_technical_fit({"technical_fit": 5}) == 7.5


def test_hardware_fit_scoring(scorer):
    """Hardware fit scoring must map 0-10 to 0-15 points."""
    assert scorer.score_hardware_fit({"hardware_fit": 0}) == 0
    assert scorer.score_hardware_fit({"hardware_fit": 10}) == 15
    assert scorer.score_hardware_fit({"hardware_fit": 5}) == 7.5


def test_setup_complexity_scoring(scorer):
    """Setup complexity must be inverted (low complexity = high score)."""
    assert scorer.score_setup_complexity({"setup_complexity": 0}) == 10  # perfect
    assert scorer.score_setup_complexity({"setup_complexity": 10}) == 0  # worst
    assert scorer.score_setup_complexity({"setup_complexity": 5}) == 5  # middle


def test_doc_quality_scoring(scorer):
    """Doc quality scoring must map 0-10 to 0-10 points."""
    assert scorer.score_doc_quality({"doc_quality": 0}) == 0
    assert scorer.score_doc_quality({"doc_quality": 10}) == 10
    assert scorer.score_doc_quality({"doc_quality": 5}) == 5


def test_competition_scoring(scorer):
    """Competition scoring must peak at moderate competition (5)."""
    moderate = scorer.score_competition({"competition": 5})
    low = scorer.score_competition({"competition": 0})
    high = scorer.score_competition({"competition": 10})
    assert moderate >= low, "Moderate competition should score >= low competition"
    assert moderate >= high, "Moderate competition should score >= high competition"


def test_reward_realism_scoring(scorer):
    """Reward realism scoring must map 0-10 to 0-10 points."""
    assert scorer.score_reward_realism({"reward_realism": 0}) == 0
    assert scorer.score_reward_realism({"reward_realism": 10}) == 10
    assert scorer.score_reward_realism({"reward_realism": 5}) == 5


def test_maintenance_scoring(scorer):
    """Maintenance scoring must be inverted (low burden = high score)."""
    assert scorer.score_maintenance({"maintenance": 0}) == 10  # perfect
    assert scorer.score_maintenance({"maintenance": 10}) == 0  # worst
    assert scorer.score_maintenance({"maintenance": 5}) == 5  # middle


def test_security_risk_scoring(scorer):
    """Security risk scoring must be inverted (low risk = high score)."""
    assert scorer.score_security_risk({"security_risk": 0}) == 5  # perfect
    assert scorer.score_security_risk({"security_risk": 10}) == 0  # worst
    assert scorer.score_security_risk({"security_risk": 5}) == 2.5  # middle


def test_learning_value_scoring(scorer):
    """Learning value scoring must map 0-10 to 0-8 points."""
    assert scorer.score_learning_value({"learning_value": 0}) == 0
    assert scorer.score_learning_value({"learning_value": 10}) == 8
    assert scorer.score_learning_value({"learning_value": 5}) == 4


def test_long_term_scoring(scorer):
    """Long-term scoring must map 0-10 to 0-7 points."""
    assert scorer.score_long_term({"long_term": 0}) == 0
    assert scorer.score_long_term({"long_term": 10}) == 7
    assert scorer.score_long_term({"long_term": 5}) == 3.5


# ---------------------------------------------------------------------------
# 3. Recommendation logic
# ---------------------------------------------------------------------------

def test_get_recommendation_high_score(scorer):
    """Score >= 70 must return HIGHLY_RECOMMENDED."""
    assert scorer.get_recommendation(70) == "HIGHLY_RECOMMENDED"
    assert scorer.get_recommendation(85) == "HIGHLY_RECOMMENDED"
    assert scorer.get_recommendation(100) == "HIGHLY_RECOMMENDED"


def test_get_recommendation_medium_score(scorer):
    """Score 40-69 must return WORTH_CONSIDERING."""
    assert scorer.get_recommendation(40) == "WORTH_CONSIDERING"
    assert scorer.get_recommendation(55) == "WORTH_CONSIDERING"
    assert scorer.get_recommendation(69) == "WORTH_CONSIDERING"


def test_get_recommendation_low_score(scorer):
    """Score < 40 must return NOT_RECOMMENDED."""
    assert scorer.get_recommendation(39) == "NOT_RECOMMENDED"
    assert scorer.get_recommendation(20) == "NOT_RECOMMENDED"
    assert scorer.get_recommendation(0) == "NOT_RECOMMENDED"


# ---------------------------------------------------------------------------
# 4. Data handling
# ---------------------------------------------------------------------------

def test_missing_data_handling(scorer):
    """Missing dimension keys should use default value of 5."""
    minimal_data = {"technical_fit": 8}
    result = scorer.score_subnet(minimal_data)
    assert isinstance(result, dict)
    assert "score" in result
    assert result["score"] > 0
    assert "breakdown" in result
    # Dimensions not provided should still be in breakdown
    assert "hardware_fit" in result["breakdown"]


def test_empty_data_returns_error(scorer):
    """Empty or None data must return an error result."""
    result_empty = scorer.score_subnet({})
    assert result_empty["score"] == 0
    assert "error" in result_empty

    result_none = scorer.score_subnet(None)
    assert result_none["score"] == 0
    assert "error" in result_none


def test_weight_sum_equals_100(scorer):
    """Sum of all dimension weights must equal 100."""
    assert scorer.weight_sum == 100, (
        f"Weights must sum to 100, got {scorer.weight_sum}"
    )


# ---------------------------------------------------------------------------
# 5. Score breakdown structure
# ---------------------------------------------------------------------------

def test_score_breakdown_contains_all_dimensions(scorer, mediocre_subnet):
    """Score result must contain all 10 scoring dimensions."""
    result = scorer.score_subnet(mediocre_subnet)
    breakdown = result.get("breakdown", {})
    expected_dimensions = [
        "technical_fit", "hardware_fit", "setup_complexity", "doc_quality",
        "competition", "reward_realism", "maintenance", "security_risk",
        "learning_value", "long_term",
    ]
    for dim in expected_dimensions:
        assert dim in breakdown, f"Missing dimension '{dim}' in score breakdown"


def test_perfect_subnet_high_score(scorer, perfect_subnet):
    """A perfect subnet must score highly (>= 80)."""
    result = scorer.score_subnet(perfect_subnet)
    assert result["score"] >= 80, (
        f"Perfect subnet should score >= 80, got {result['score']}"
    )
    assert result["recommendation"] == "HIGHLY_RECOMMENDED"


def test_poor_subnet_low_score(scorer, poor_subnet):
    """A poor subnet must score low (< 40)."""
    result = scorer.score_subnet(poor_subnet)
    assert result["score"] < 40, (
        f"Poor subnet should score < 40, got {result['score']}"
    )
    assert result["recommendation"] == "NOT_RECOMMENDED"
